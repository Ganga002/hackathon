package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class Logindao {

	public static boolean validate(String user,String pass,String type) {
		boolean status=false;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/apptoc","root","");
		PreparedStatement ps=con.prepareStatement("select * from login1 where username=? and password=? and type=?");
		ps.setString(1,user);
		ps.setString(2,pass);
		ps.setString(3,type);
		ResultSet rs=ps.executeQuery();
status=rs.next();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		System.out.println(status);
		return status;
		// TODO Auto-generated method stub
		
	}

}
