package Dao;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;

	public class MainDao {

			static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
			static final String DB_URL = "jdbc:mysql://localhost/apptoc";

			static final String USER = "root";
			static final String PASS = "";
			static Connection con;

			public static Connection getConnection() {

				try {
					Class.forName(JDBC_DRIVER);
					System.out.println("Connecting to database...");
			 con = DriverManager.getConnection(DB_URL,USER,PASS);
			 System.out.println("Connected to database...");
				} catch (Exception exp) {
					
		System.out.println();
				}
				return con;
			}

}
