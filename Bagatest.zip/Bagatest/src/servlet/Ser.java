package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Ser
 */
@WebServlet("/Ser")
public class Ser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	int a=0;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Ser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		if(Integer.parseInt(request.getParameter("name").toString())==1)
		{
		a=a+4;
		request.setAttribute("name", a);
		RequestDispatcher rd=request.getRequestDispatcher("index1.jsp");  
		rd.forward(request, response);
	    }
		else
		{
			a=a-4;
			if(a==0)
			{
			request.setAttribute("name", a);
			RequestDispatcher rd=request.getRequestDispatcher("index.jsp");  
			rd.forward(request, response);
			}
			else
			{
				request.setAttribute("name", a);
				RequestDispatcher rd=request.getRequestDispatcher("index1s.jsp");  
				rd.forward(request, response);
			}
		}

		}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		/*a=a-4;
		if(a==0)
		{
		request.setAttribute("name", a);
		RequestDispatcher rd=request.getRequestDispatcher("NewFile.jsp");  
		rd.forward(request, response);
		}
		else
		{
			request.setAttribute("name", a);
			RequestDispatcher rd=request.getRequestDispatcher("NewFile1.jsp");  
			rd.forward(request, response);
		}*/
	}

}
