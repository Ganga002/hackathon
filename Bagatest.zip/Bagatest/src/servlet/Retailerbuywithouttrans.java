package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dao.MainDao;

/**
 * Servlet implementation class Retailerbuywithouttrans
 */
@WebServlet("/Retailerbuywithouttrans")
public class Retailerbuywithouttrans extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Retailerbuywithouttrans() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
	
		
		
		String farmer =request.getParameter("user_namefar");
	
		String Ruser=request.getParameter("user_idret");
			
		double base=Double.parseDouble(request.getParameter("baseprice").toString());
		int t_id=Integer.parseInt(request.getParameter("t_id"));
		
		int required=Integer.parseInt(request.getParameter("required_quantity").toString());
		System.out.println("re"+required);
	
		int available=Integer.parseInt(request.getParameter("size").toString());
		
		if(required == available)
		{
			try {
				Statement st=MainDao.getConnection().createStatement();
				String sql="insert into history (Farmer_id,Retailer_id,Sold,Base_price) values ('"+farmer+"','"+Ruser+"',"+required+","+base+")";
				st.executeUpdate(sql);
				sql="delete from trans where t_id="+t_id;
				st.executeUpdate(sql);
				System.out.println("Succes");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		else if(required < available)
		{
			try {
			Statement st=MainDao.getConnection().createStatement();
			String sql="insert into history (Farmer_id,Retailer_id,Sold,Base_price) values ('"+farmer+"','"+Ruser+"',"+required+","+base+")";
			st.executeUpdate(sql);
			int temp=available-required;
			sql="update trans set size="+temp+" where t_id="+t_id;
			st.executeUpdate(sql);
			System.out.println("Succes");
			RequestDispatcher td=request.getRequestDispatcher("alert.jsp");
			td.forward(request, response);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
			
		}
		else
		{
              PrintWriter out=response.getWriter();			
			out.println("<script type=\"text/javascript\">");
			   out.println("alert('User or password incorrect');");
			   out.println("location='index.jsp';");
			   out.println("</script>");
			   
			
		}
	}

}

