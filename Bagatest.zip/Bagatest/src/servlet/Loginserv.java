package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.Logindao;

/**
 * Servlet implementation class Loginserv
 */
@WebServlet("/Loginserv")
public class Loginserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Loginserv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		String user=request.getParameter("username");
		String pass=request.getParameter("password");
		String type=request.getParameter("type");
		
		if(Logindao.validate(user,pass,type))
		{
		 HttpSession session=request.getSession();
			if(request.getParameter("type").equals("Farmer"))
			{
				session.setAttribute("username", user);
				session.setAttribute("type",request.getParameter("type"));
				response.sendRedirect("index.jsp");
			}
			else if(request.getParameter("type").equals("Retailer"))
			{
				session.setAttribute("username", user);
				session.setAttribute("type", request.getParameter("type"));
				response.sendRedirect("Retailer_main.jsp");
			}
			else if(request.getParameter("type").equals("Food Industries"))
			{
				session.setAttribute("username", user);
				session.setAttribute("type", request.getParameter("type"));
				response.sendRedirect("Food_industries.jsp");
			}
			else if(request.getParameter("type").equals("Transport"))
			{
				session.setAttribute("username", user);
				session.setAttribute("type", request.getParameter("type"));
				response.sendRedirect("Transport.jsp");
			}
			else if(request.getParameter("type").equals("Fertilizer"))
			{
				session.setAttribute("username", user);
				session.setAttribute("type", request.getParameter("type"));
				response.sendRedirect("Fertilizer.jsp");
			}
		}
		else
		{
			PrintWriter out=response.getWriter();
			 out.println("<script type=\"text/javascript\">");
		       out.println("alert('User or password incorrect');");
		       out.println("</script>");
			response.sendRedirect("login.jsp");
		}
		
	}
	}


