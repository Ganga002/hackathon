
$(document).ready(function(){
$("#navbar-frame").load("/footer.html");
});