package com.Dao;

import com.Pojo.RegisterPojo;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class RegisterDao {

	public static void insertFarmer(RegisterPojo rs) {
		Connection con=null;
		try
		{
			con=(Connection) MainDao.getConnection();
			 System.out.println("Connecting to database...");
			//sql="insert into stu(username,password) values('"+pj.getUsername()+"','"+pj.getPassword()+"')";
			String sql="insert into farmer(username,firstname,lastname,password,retypepassword,gender,address,city,phone,email,type,aadhaar,farmerid)values('"+rs.getUsername()+"','"+rs.getFirstname()+"','"+rs.getLastname()+"','"+rs.getPassword()+"','"+rs.getRetypepassword()+"','"+rs.getGender()+"','"+rs.getAddress()+"','"+rs.getCity()+"','"+rs.getPhone()+"','"+rs.getEmail()+"','"+rs.getType()+"','"+rs.getAadhaar()+"','"+rs.getFarmerid()+"')";
			//String sql="insert into farmer(username,firstname,lastname,password,retypepassword,gender,address,city,phone,email,type,aadhaar,farmerid)values(username,firstname,lastname,password,retypepassword,gender,address,city,phone,email,type,aadhaar,farmerid)";
			Statement st = (Statement) con.createStatement();
			st.executeUpdate(sql);
			System.out.println("Inserted");
			con.close();
		}catch(Exception e)
		{
			System.out.println("exception");
		}
	}
	public static void insertRetailer(RegisterPojo rs) {
		try
		{
			Connection con = (Connection) MainDao.getConnection();
			String sql="insert into retailer(username,firstname,lastname,password,retypepassword,gender,address,city,phone,email,type,shopname,reatilerid,alterphone)values(username,firstname,lastname,password,retypepassword,gender,address,city,phone,email,type,shopname,reatilerid,alterphone)";
			Statement st = (Statement) con.createStatement();
			st.executeUpdate(sql);
			con.close();
		}catch(Exception e)
		{
			System.out.println("exception");
		}  
		
	}

	public static void insertFoodindustry(RegisterPojo rs) {
		try
		{
		Connection con = (Connection) MainDao.getConnection();
		String sql="insert into foodindustry(username,firstname,lastname,password,retypepassword,gender,address,city,phone,email,type,foodcompanyname,foodlicense)values(username,firstname,lastname,password,retypepassword,gender,address,city,phone,email,type,foodcompanyname,foodlicense)";
		Statement st = (Statement) con.createStatement();
		st.executeUpdate(sql);
		con.close();
		}catch(Exception e)
		{
			System.out.println("exception");
		}  
	}

	public static void insertTransport(RegisterPojo rs) {
		// TODO Auto-generated method stub
		
	}

	public static void insertFertilizer(RegisterPojo rs) {
		// TODO Auto-generated method stub
		
	}

}
