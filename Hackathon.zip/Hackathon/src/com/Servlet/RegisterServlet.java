package com.Servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.Dao.RegisterDao;
import com.Pojo.RegisterPojo;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int a=Integer.parseInt(request.getParameter("type"));
		if(a==1)
		{
		RegisterPojo rs=new RegisterPojo();
		rs.setUsername(request.getParameter("username"));
		rs.setFirstname(request.getParameter("firstname"));
		rs.setLastname(request.getParameter("lastname"));
		rs.setPassword(request.getParameter("password"));
		rs.setRetypepassword(request.getParameter("retypepassword"));
		rs.setGender(request.getParameter("gender"));
		rs.setAddress(request.getParameter("address"));
		rs.setCity(request.getParameter("city"));
		rs.setState(request.getParameter("state"));
		rs.setPincode(Integer.parseInt(request.getParameter("pincode")));
		rs.setPhone(Integer.parseInt(request.getParameter("phone")));
		rs.setEmail(request.getParameter("email"));
		rs.setType(Integer.parseInt(request.getParameter("type")));
		rs.setAadhaar(request.getParameter("aadhar"));
		rs.setFarmerid(request.getParameter("farmerid"));
		RegisterDao.insertFarmer(rs);
		RequestDispatcher rs1=request.getRequestDispatcher("farmar.jsp");
		rs1.include(request, response);
		}
		if(a==2)
		{
			RegisterPojo rs=new RegisterPojo();
			rs.setUsername(request.getParameter("username"));
			rs.setFirstname(request.getParameter("firstname"));
			rs.setLastname(request.getParameter("lastname"));
			rs.setPassword(request.getParameter("password"));
			rs.setRetypepassword(request.getParameter("retypepassword"));
			rs.setGender(request.getParameter("gender"));
			rs.setAddress(request.getParameter("address"));
			rs.setCity(request.getParameter("city"));
			rs.setState(request.getParameter("state"));
			rs.setPincode(Integer.parseInt(request.getParameter("pincode")));
			rs.setPhone(Integer.parseInt(request.getParameter("phone")));
			rs.setEmail(request.getParameter("email"));
			rs.setType(Integer.parseInt(request.getParameter("type")));
			rs.setShopname(request.getParameter("shopname"));
			rs.setRetailerid(request.getParameter("retailerid"));
			rs.setAlterphone(Integer.parseInt(request.getParameter("alterphone")));
			RegisterDao.insertRetailer(rs);
			RequestDispatcher rs1=request.getRequestDispatcher("retailer.jsp");
			rs1.include(request, response);	
		}
		if(a==3)
		{
			RegisterPojo rs=new RegisterPojo();
			rs.setUsername(request.getParameter("username"));
			rs.setFirstname(request.getParameter("firstname"));
			rs.setLastname(request.getParameter("lastname"));
			rs.setPassword(request.getParameter("password"));
			rs.setRetypepassword(request.getParameter("retypepassword"));
			rs.setGender(request.getParameter("gender"));
			rs.setAddress(request.getParameter("address"));
			rs.setCity(request.getParameter("city"));
			rs.setState(request.getParameter("state"));
			rs.setPincode(Integer.parseInt(request.getParameter("pincode")));
			rs.setPhone(Integer.parseInt(request.getParameter("phone")));
			rs.setEmail(request.getParameter("email"));
			rs.setType(Integer.parseInt(request.getParameter("type")));
			rs.setFoodcompanyname(request.getParameter("foodcompanyname"));
			rs.setFoodlicensenumber(request.getParameter("foodlicensenumber"));
			RegisterDao.insertFoodindustry(rs);
			RequestDispatcher rs1=request.getRequestDispatcher("foodindustry.jsp");
			rs1.include(request, response);
		}
		if(a==4)
		{
			RegisterPojo rs=new RegisterPojo();
			rs.setUsername(request.getParameter("username"));
			rs.setFirstname(request.getParameter("firstname"));
			rs.setLastname(request.getParameter("lastname"));
			rs.setPassword(request.getParameter("password"));
			rs.setRetypepassword(request.getParameter("retypepassword"));
			rs.setGender(request.getParameter("gender"));
			rs.setAddress(request.getParameter("address"));
			rs.setCity(request.getParameter("city"));
			rs.setState(request.getParameter("state"));
			rs.setPincode(Integer.parseInt(request.getParameter("pincode")));
			rs.setPhone(Integer.parseInt(request.getParameter("phone")));
			rs.setEmail(request.getParameter("email"));
			rs.setType(Integer.parseInt(request.getParameter("type")));
			rs.setTranscompanyname(request.getParameter("transcompanyname"));
			rs.setTranslicensenumber(request.getParameter("translicensenumber"));
			RegisterDao.insertTransport(rs);
			RequestDispatcher rs1=request.getRequestDispatcher("transport.jsp");
			rs1.include(request, response);
		}
		if(a==5)
		{
			RegisterPojo rs=new RegisterPojo();
			rs.setUsername(request.getParameter("username"));
			rs.setFirstname(request.getParameter("firstname"));
			rs.setLastname(request.getParameter("lastname"));
			rs.setPassword(request.getParameter("password"));
			rs.setRetypepassword(request.getParameter("retypepassword"));
			rs.setGender(request.getParameter("gender"));
			rs.setAddress(request.getParameter("address"));
			rs.setCity(request.getParameter("city"));
			rs.setState(request.getParameter("state"));
			rs.setPincode(Integer.parseInt(request.getParameter("pincode")));
			rs.setPhone(Integer.parseInt(request.getParameter("phone")));
			rs.setEmail(request.getParameter("email"));
			rs.setType(Integer.parseInt(request.getParameter("type")));
			rs.setFertilizercompanyname(request.getParameter("fertilizercompanyname"));
			rs.setFertilizerlicenseno(request.getParameter("fertilizerlicenseno"));
			RegisterDao.insertFertilizer(rs);
			RequestDispatcher rs1=request.getRequestDispatcher("transport.jsp");
			rs1.include(request, response);
		}
	}

}
