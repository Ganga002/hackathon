package com.Pojo;

public class RegisterPojo {
	private String username;
    private String firstname;
    private String lastname;
    private String password;
    private String retypepassword;
    private String gender;
    private String address;
    private String city;
    private String state;
    private int pincode;
    private int phone;
    private String email;
    private int type;
    private String aadhaar;
    private String farmerid;
    private String shopname;
    private String retailerid;
    private int alterphone;
    private String foodcompanyname;
    private String foodlicensenumber;
    private String transcompanyname;
    private String translicensenumber;
    private String fertilizercompanyname;
    private String fertilizerlicenseno;
    public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRetypepassword() {
		return retypepassword;
	}
	public void setRetypepassword(String retypepassword) {
		this.retypepassword = retypepassword;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getAadhaar() {
		return aadhaar;
	}
	public void setAadhaar(String string) {
		this.aadhaar = string;
	}
	public String getFarmerid() {
		return farmerid;
	}
	public void setFarmerid(String string) {
		this.farmerid = string;
	}
	public String getShopname() {
		return shopname;
	}
	public void setShopname(String shopname) {
		this.shopname = shopname;
	}
	public String getRetailerid() {
		return retailerid;
	}
	public void setRetailerid(String string) {
		this.retailerid = string;
	}
	public int getAlterphone() {
		return alterphone;
	}
	public void setAlterphone(int alterphone) {
		this.alterphone = alterphone;
	}
	public String getFoodcompanyname() {
		return foodcompanyname;
	}
	public void setFoodcompanyname(String foodcompanyname) {
		this.foodcompanyname = foodcompanyname;
	}
	public String getFoodlicensenumber() {
		return foodlicensenumber;
	}
	public void setFoodlicensenumber(String foodlicensenumber) {
		this.foodlicensenumber = foodlicensenumber;
	}
	public String getTranscompanyname() {
		return transcompanyname;
	}
	public void setTranscompanyname(String transcompanyname) {
		this.transcompanyname = transcompanyname;
	}
	public String getTranslicensenumber() {
		return translicensenumber;
	}
	public void setTranslicensenumber(String translicensenumber) {
		this.translicensenumber = translicensenumber;
	}
	public String getFertilizercompanyname() {
		return fertilizercompanyname;
	}
	public void setFertilizercompanyname(String fertilizercompanyname) {
		this.fertilizercompanyname = fertilizercompanyname;
	}
	public String getFertilizerlicenseno() {
		return fertilizerlicenseno;
	}
	public void setFertilizerlicenseno(String fertilizerlicenseno) {
		this.fertilizerlicenseno = fertilizerlicenseno;
	}
}
